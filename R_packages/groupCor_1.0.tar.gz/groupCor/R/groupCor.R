## one To all cor pearson
one2All_cor <- function(y, ys, target) { 
  means<-apply(ys,1, mean); class(means); length(means)
  sds <- apply(ys,1, sd); class(means); length(means)
  
  xcortest<-function(x,y){
    res<-cor.test(x, y)
    return( c(res$p.value, res$estimate) )
  }
  
  cor_multitraits <- function(x, ys){  no.ys = dim(ys)[1] 
  mres  = NULL
  for (j in c(1:no.ys)){
    jres = xcortest(x, ys[j,]) 
    mres = rbind(mres, jres)
  }
  return (mres)
  }
  
  ccc <- cor_multitraits (y, ys)
  
  row.names(ccc) <- row.names(ys); colnames(ccc) <- c("p.value","cor.coefficient")
  
  p_bonferroni <- p.adjust(ccc[,1], method ="bonferroni", n = length(ccc[,1])); length(p_bonferroni)
  p_BH <- p.adjust(ccc[,1], method ="BH", n = length(ccc[,1])); length(p_BH)
  
  df<- data.frame(mean=means, sd=sds, Cor.coef.with.target= ccc[,2], 
                  p.value=ccc[,1],p.bonferroni= p_bonferroni, p.BH=p_BH, Module_target=target)
  dim(df)
  row.names(df) <- paste(row.names(ys), target, sep="_")
  return (df)
}

## one To all cor spearman

one2All_cor.spearman <- function(y, ys, target) { 
  means<-apply(ys,1, mean); class(means); length(means)
  sds <- apply(ys,1, sd); class(means); length(means)
  
  xcortest<-function(x,y){
  res<-cor.test(x, y, method = "spearman")
  return( c(res$p.value, res$estimate) )
  }
  
  cor_multitraits <- function(x, ys){  no.ys = dim(ys)[1] 
  mres  = NULL
  for (j in c(1:no.ys)){
    jres = xcortest(x, ys[j,]) 
    mres = rbind(mres, jres)
  }
  return (mres)
  }
  
  ccc<-cor_multitraits (y, ys)
  row.names(ccc)<-row.names(ys); colnames(ccc)<-c("p.value","cor.coefficient")
  
  p_bonferroni <- p.adjust(ccc[,1], method ="bonferroni", n = length(ccc[,1])); length(p_bonferroni)
  p_BH <- p.adjust(ccc[,1], method ="BH", n = length(ccc[,1])); length(p_BH)
  
  df<- data.frame(mean=means, sd=sds, Cor.coef.with.target= ccc[,2], 
                  p.value=ccc[,1],p.bonferroni=p_bonferroni, p.BH=p_BH, Module_target=target)
  dim(df)
  row.names(df) <- paste(row.names(ys), target, sep="_")
  return (df)
}

##################
all2all.cor <- function (mat, genelist) { # genelist: 2 cols: col#2: categorical (1) or continous (0)
  df<- NULL
  
  for (i in 1:dim(genelist)[1]) {
    y <- mat[row.names(mat)%in% genelist[i,1],]
    target <- genelist[i,1]
    ys <-  mat[!row.names(mat)%in% genelist[,1],]
    if (genelist[i,2] == 1 ) {
    df <- rbind(df, one2All_cor.spearman (y, ys, target))
    
                 } else {
    df <- rbind(df, one2All_cor (y, ys, target))
                        } 
  
  } ## for                
  df <- cbind( geneID = gsub("\\_.*","", row.names(df)), df)  
  return (df)
  } ## all2all.cor function
###################
## over
